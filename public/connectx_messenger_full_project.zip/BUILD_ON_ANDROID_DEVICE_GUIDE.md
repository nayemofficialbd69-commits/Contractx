# How to Build APK Directly on an Android Device (No PC Required)

You can compile this Android project directly on your Android phone/tablet using Termux!

## Requirements:
- Android phone with at least 4GB RAM and 3GB free storage
- **Termux** app (Download from F-Droid or GitHub, NOT the outdated Play Store version)

## Step-by-Step Instructions:

1. Open Termux and update packages:
   ```bash
   pkg update && pkg upgrade -y
   ```

2. Install OpenJDK 17 and developer utilities:
   ```bash
   pkg install openjdk-17 git unzip wget -y
   ```

3. Unzip the project files:
   ```bash
   unzip connectx_messenger_full_project.zip -d connectx
   cd connectx/android
   ```

4. Grant execute permission to Gradle wrapper:
   ```bash
   chmod +x gradlew
   ```

5. Set your JAVA_HOME:
   ```bash
   export JAVA_HOME=$PREFIX/opt/openjdk-17
   ```

6. Build the Debug APK:
   ```bash
   ./gradlew assembleDebug
   ```

7. Find your APK at:
   ```text
   app/build/outputs/apk/debug/app-debug.apk
   ```
   Copy it to your phone's Download folder:
   ```bash
   termux-setup-storage
   cp app/build/outputs/apk/debug/app-debug.apk /sdcard/Download/ConnectX.apk
   ```
   Then open your phone's File Manager > Downloads and tap ConnectX.apk to install!
